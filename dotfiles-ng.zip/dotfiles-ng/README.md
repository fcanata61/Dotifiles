<div align="justify">

<div align="center">

```ocaml
NEVER SKIP / IGNORE / AVOID README
```

```css
      __/)   ‌‌‌‌‬‬‬‍ ‌‌‌‌‌‬‌‌   ‌‌‌‌‌﻿‌‬ ‌‌‌‌‌﻿‌‌‌‌‌‌‌﻿‌‬        ‌‌‌‌‌﻿‌‬_      ‌‌‌‌‌‬‌‌_       ‌‌‌‌‍‬﻿﻿  ‌‌‌‌‍﻿‍﻿ 
   .‌‌‌‌‍‬﻿‌-(_‌‌‌‌‌﻿‍‌_(=:   |   ‌‌‌‌‍‬‌﻿   ‌‌‌‌‍‬‍‍   ‌‌‌‌‌‬‌‌ | | o  | |     ‌‌‌‌‌﻿﻿‌    
‌‌‌‌‍‬‌‍|\ |    \) ‌‌‌‌‍‬﻿‌ _‌‌‌‌‍﻿‍‌_| ‌‌‌‌‍‬‍‍  __ ‌‌‌‌‍﻿‌‬_|‌‌‌‌‍‬﻿‬_ | |‌‌‌‌‍‬‌‍    |‌‌‌‌‍﻿‍‌ |  _ ‌‌‌‌‍‬‍‍  , ‌‌‌‌‌‬﻿‍ 
‌‌‌‌‍﻿‌﻿\‌‌‌‌‍‬‍‍ ||       / ‌‌‌‌‌﻿‍﻿ ‌‌‌‌‍‬‍‍|  /  \_|  |/‌‌‌‌‍‬﻿‬  |  |/  |/  / \‌‌‌‌‍‌‌‌‌‌‌‌‍﻿‌‌_
 \||     ‌‌‌‌‍‬﻿‍  \_/|_/\__/ |_‌‌‌‌‌‬﻿‬/‌‌‌‌‍‬﻿‍|__/|_‌‌‌‌‍‬‍‍/|__/‌‌‌‌‌﻿﻿‬|__/ \/ 
  \|                     |\                 
   |  6F 77 6C 34 63 65  |/  with aesthetics
```

</div>

<pre align="center">
<a href="#seedling--setup">SETUP</a> • <a href="#four_leaf_clover--key-bindings">KEYBINDS</a> • <a href="https://deviantart.com/owl4ce/art/Sakura-Saber-872360153">GALLERY</a> • <a href="#herb--guides">GUIDES</a>
</pre>

<h1>
  <a href="#--------">
    <img alt="" align="right" src="https://badges.pufler.dev/visits/owl4ce/dotfiles?style=flat-square&label=&color=000000&logo=github&logoColor=white&labelColor=000000"/>
  </a>
</h1>

### :octocat: ‎ <sup><sub><samp>HI THERE! THANKS FOR DROPPING BY!</samp></sub></sup>

<a href="#octocat--hi-there-thanks-for-dropping-by">
  <picture>
    <source media="(prefers-color-scheme: dark)" alt="" align="right" width="400px" srcset="https://i.imgur.com/7pWg4vR.jpg"/>
    <img alt="" align="right" width="400px" src="https://i.imgur.com/VMiaVX3.jpg"/>
  </picture>
</a>

You might be here looking for (Linux) rice reference or to (full?) replicate my personal
configuration of my favorite Openbox Window Manager and several apps as well. :snowman:

Most were written from scratch. Some details:

- **Window Manager** :bento: [Openbox](http://openbox.org/wiki/Main_Page) dual themes!
- **Openbox Menu** :cyclone: [obmenu-generator](https://github.com/trizen/obmenu-generator) for life!
- **Panel** :blossom: [Tint2](https://gitlab.com/o9000/tint2) with material design and glyphs!
- **Application Launcher** :rocket: [Rofi](https://github.com/davatorium/rofi) which blazing fast!
- **Desktop Notification** :herb: [Dunst](https://github.com/dunst-project/dunst) which minimalist!
- **Terminal Emulator** :leaves: [URxvt](http://software.schmorp.de/pkg/rxvt-unicode.html) which lightest!
- **Shell** :shell: [Zsh](https://zsh.org) with [oh-my-zsh](https://github.com/ohmyzsh/ohmyzsh) framework!
- **Compositor** :shaved_ice: [Picom](https://github.com/yshui/picom) for perfection topping!
- **File Manager** :flower_playing_cards: [Thunar](https://docs.xfce.org/xfce/thunar/start) customized side-pane!
- **Media Player** :city_sunset: [mpv](https://mpv.io) with modern OSC!
- **Music Player** :milky_way: [Ncmpcpp](https://github.com/ncmpcpp/ncmpcpp) with album-art!
- **GUI (Basic) IDE** :space_invader: [Geany](https://geany.org) for the win!

<h1>
  <a href="#---------1">
    <img alt="" align="right" src="https://img.shields.io/github/commit-activity/m/owl4ce/dotfiles/ng?style=flat-square&label=&color=000000&logo=gitbook&logoColor=white&labelColor=000000"/>
  </a>
</h1>

<br>

<div align="center">

```ocaml
CLICK OR TAP ❲☰❳ TO SHOW TABLE-OF-CONTENTS
```

</div>

<p align="right">
  [<a href="https://gitlab.com/owl4ce/dotfiles">mirror</a>]
</p>

## :fallen_leaf: ‎ <samp>CHANGELOGS</samp>

<table align="right">
  <tr>
    <th align="center">
      <sup><sub>:warning:</sub></sup>
    </th>
  </tr>
  <tr>
    <td align="center">
      <a href="https://github.com/owl4ce/dotfiles/discussions/172">
        <sup><sub><samp>PURELY CONFIGURED AT 1366x768 WITH 96 DPI</samp></sub></sup>
      </a>
    </td>
  </tr>
  <tr>
    <td align="center">
      <a href="https://wiki.gentoo.org/wiki/Benefits_of_Gentoo">
        <sup><sub><samp>Powered by Gentoo/Linux x86_64</samp></sub></sup>
      </a>
    </td>
  </tr>
</table>

> From the previous major versions (0-3.x).

<details>
<summary><b>Innovations</b></summary>

- **Functionality**
  - [Live reloader](./.config/openbox/joyful-desktop/terminal-set.sh#L66-L123) for rxvt-unicode color scheme
- **Git repository**
  - [CODE_OF_CONDUCT.md](./CODE_OF_CONDUCT.md)
  - [CONTRIBUTING.md](./CONTRIBUTING.md)
  - [README.md](./README.md)
  - [REPOLOGY.md](./REPOLOGY.md)
  - [SECURITY.md](./SECURITY.md)
- **User interface**
  - Rofi [main menu](./.config/rofi/scripts/rofi-main.sh) and panel (or control)
    [extensions menu](./.config/rofi/scripts/rofi-exts.sh)
  - Rofi [action menu](./.config/rofi/themes/action.rasi) for openbox
    [button](./.config/openbox/joyful-desktop/ob-button-set.sh#L16-L24) and X
    [wallpaper](./.config/openbox/joyful-desktop/wallpaper-set.sh#L16-L24) selectors,
    as well as dunst [context-menu](./.config/dunst/mechanical.artistic.dunstrc#L40)
  - Better tint2 [horizontal panels](./.config/tint2) for Artistic Mode and the tooltips

</details>

<details>
<summary><b>Renovations</b></summary>

- **GTK theme and icon updates and fixes**
  - [Papirus-Custom](https://github.com/owl4ce/dotfiles/releases/download/ng/Papirus-Custom_JfD.tar.xz) and
    [Papirus-Dark-Custom](https://github.com/owl4ce/dotfiles/releases/download/ng/Papirus-Dark-Custom_JfD.tar.xz)
    patches
    - 16x16
      - apps
        - diodon.svg
      - devices
        - drive-harddisk.svg
        - drive-removable-media-usb.svg
        - phone.svg
      - places
        - folder.svg
        - folder-documents.svg 🡲 folder.svg
        - folder-download.svg 🡲 folder.svg
        - folder-music.svg 🡲 folder.svg
        - folder-network.svg
        - folder-pictures.svg 🡲 folder.svg
        - folder-video.svg 🡲 folder.svg
    - 48x48
      - status
        - battery-ac-adapter.svg
        - battery-caution-charging.svg
        - battery-caution.svg
        - battery-empty-charging.svg
        - battery-empty.svg
        - battery-full-charged.svg
        - battery-full-charging.svg
        - battery-full.svg
        - battery-good-charging.svg
        - battery-good.svg
        - battery-low-charging.svg
        - battery-low.svg
        - battery-missing.svg
        - bluetooth-active.svg
        - bluetooth-disabled.svg
        - bluetooth.svg
        - dialog-error.svg
        - dialog-information.svg
        - dialog-question.svg
        - dialog-warning.svg
        - network-error.svg
        - network-offline.svg
        - network-wired-disconnected.svg
        - network-wireless-encrypted.svg
        - nm-signal-100.svg
        - nm-signal-25.svg
        - nm-signal-50.svg
        - nm-signal-75.svg
        - notification-audio-volume-high.svg
        - notification-audio-volume-low.svg
        - notification-audio-volume-medium.svg
        - notification-audio-volume-muted.svg
        - notification-battery-low.svg
        - notification-device-eject.svg
        - notification-display-brightness-full.svg
        - notification-display-brightness-high.svg
        - notification-display-brightness-low.svg
        - notification-display-brightness-medium.svg
        - notification-display-brightness-off.svg
        - notification-network-ethernet-connected.svg
        - notification-network-wireless-disconnected.svg
        - notification-network-wireless.svg
- **Reconfigure program configurations**
- **Restructure git directory layouts**
- **Rewrite shell-scripts completely**
  - Use POSIX-compliant sh for portability
  - Harden algorithm as possible for safety
  - Use built-in shell features for high-performance
  - Optimize algorithm to reduce overheads
  - Bug fixes across ecosystem environments

</details>

<details>
<summary><b>Removals</b></summary>

- **Mostly deprecated configs and BLOBs such as images**

</details>

*..., and is still being improved.*

## :seedling: ‎ <samp>SETUP</samp>

Everything done manually step-by-step. Let's learn. [中文教程](https://www.maredevi.fun/2022/09/29/)

### :blossom: ‎ <samp>INSTALLATION (<a href="./REPOLOGY.md">DEPENDENCIES</a>)</samp>

<details>
<summary><b>1. Debian-based Linux distributions</b></summary>

[Debian SID](https://wiki.debian.org/DebianUnstable) or [Devuan (ceres?)](https://devuan.org/os/releases) recommended.

**Didn't know how to install packages?**

```sh
💲 sudo apt install atom1 atom2 ... atomN
```

---

**X.Org server and {it's,core} utilities. This is essentials.**

```sh
xserver-xorg-core x11-xserver-utils psmisc
```

Contents of [1](https://packages.debian.org/sid/xserver-xorg-core),
[2](https://packages.debian.org/sid/x11-xserver-utils),
[3](https://packages.debian.org/sid/psmisc).

[Here for python (3) if not already installed](https://wiki.debian.org/Python).

---

**Now, the UI kits and functionality. This is required.**

URxvt is highly recommended terminal emulator by default. Picom is optional, but recommended.

```sh
dunst nitrogen openbox rofi rxvt-unicode tint2 picom libgtk3-perl #obmenu-generator
```

Contents of [1](https://packages.debian.org/sid/dunst),
[2](https://packages.debian.org/sid/nitrogen),
[3](https://packages.debian.org/sid/openbox),
[4](https://packages.debian.org/sid/rofi),
[5](https://packages.debian.org/sid/rxvt-unicode),
[6](https://packages.debian.org/sid/tint2),
[7](https://packages.debian.org/sid/picom),
[8](https://packages.debian.org/sid/libgtk3-perl).

[Here to install obmenu-generator](https://software.opensuse.org/download.html?project=home%3AHead_on_a_Stick%3Aobmenu-generator&package=obmenu-generator).

---

**Audio-server and audio stuff.**

I personally use pulseaudio, mpd and ncmpcpp are recommended as they are integrated by default.

```sh
pulseaudio mpd mpc ncmpcpp
```

Contents of [1](https://packages.debian.org/sid/pulseaudio),
[2](https://packages.debian.org/sid/mpd),
[3](https://packages.debian.org/sid/mpc),
[4](https://packages.debian.org/sid/ncmpcpp).

MPRIS-enabled media players are also integrated, such as [spotify](https://wiki.debian.org/spotify).

---

**Extended utilities. Required, but just as necessary.**

All of the below if not installed, certain functionality will display a message when needed, some will not.

```sh
alsa-utils brightnessctl imagemagick scrot w3m-img wireless-tools xclip xsettingsd xss-lock
```

Contents of [1](https://packages.debian.org/sid/alsa-utils),
[2](https://packages.debian.org/sid/brightnessctl),
[3](https://packages.debian.org/sid/imagemagick),
[4](https://packages.debian.org/sid/scrot),
[5](https://packages.debian.org/sid/w3m-img),
[6](https://packages.debian.org/sid/wireless-tools),
[7](https://packages.debian.org/sid/xclip),
[8](https://packages.debian.org/sid/xsettingsd),
[9](https://packages.debian.org/sid/xss-lock).

Choose your own polkit authentication-agent. [lxpolkit](https://packages.debian.org/sid/lxpolkit)?

---

**Additionals for completion of desktop compositions.**

Just like mpd and ncmpcpp, configurations are included as [EXTRA_JOYFUL](./EXTRA_JOYFUL), some are integrated.

```sh
thunar thunar-archive-plugin thunar-volman ffmpegthumbnailer tumbler
```

Contents of [1](https://packages.debian.org/sid/thunar),
[2](https://packages.debian.org/sid/thunar-archive-plugin),
[3](https://packages.debian.org/sid/thunar-volman),
[4](https://packages.debian.org/sid/ffmpegthumbnailer),
[5](https://packages.debian.org/sid/tumbler).

Gsimplecal was used to display calendar pop-ups from the tint2 panel, and pavucontrol to control pulseaudio-sinks.

```sh
geany geany-plugins gimp gsimplecal inkscape mpv parcellite pavucontrol viewnior xfce4-power-manager
```

Contents of [1](https://packages.debian.org/sid/geany),
[2](https://packages.debian.org/sid/geany-plugins),
[3](https://packages.debian.org/sid/gimp),
[4](https://packages.debian.org/sid/gsimplecal),
[5](https://packages.debian.org/sid/inkscape),
[6](https://packages.debian.org/sid/mpv),
[7](https://packages.debian.org/sid/parcellite),
[8](https://packages.debian.org/sid/pavucontrol),
[9](https://packages.debian.org/sid/viewnior),
[10](https://packages.debian.org/sid/xfce4-power-manager).

I personally don't use neofetch anymore and use system-information via rofi, it's already scripted.

```sh
htop nano #neofetch
```

Contents of [1](https://packages.debian.org/sid/htop),
[2](https://packages.debian.org/sid/nano),
[3](https://packages.debian.org/sid/neofetch).

[Here for improved nanorc with syntax-highlighting](https://github.com/scopatz/nanorc).

I personally use NetworkManager (and IWD as wireless back-end) with nm-applet,
[here it is](https://wiki.debian.org/NetworkManager).

</details>

<details>
<summary><b>1. Arch-based Linux distributions</b></summary>

[Arch Linux](https://archlinux.org) and [Artix Linux](https://artixlinux.org) recommended.

**Didn't know how to install packages?**

```sh
💲 sudo pacman -S atom1 atom2 ... atomN
```

---

**X.Org server and {it's,core} utilities. This is essentials.**

```sh
xorg-server xorg-xrandr xorg-xrdb psmisc
```

Contents of [1](https://archlinux.org/packages/extra/x86_64/xorg-server),
[2](https://archlinux.org/packages/extra/x86_64/xorg-xrandr),
[3](https://archlinux.org/packages/extra/x86_64/xorg-xrdb),
[4](https://archlinux.org/packages/core/x86_64/psmisc).

[Here for python (3) if not already installed](https://wiki.archlinux.org/title/python).

---

**Now, the UI kits and functionality. This is required.**

URxvt is highly recommended terminal emulator by default. Picom is optional, but recommended.

> **AUR**  
> `rxvt-unicode-truecolor-wide-glyphs`  
> `obmenu-generator`

```sh
dunst nitrogen openbox rofi rxvt-unicode-truecolor-wide-glyphs tint2 picom obmenu-generator perl-gtk3
```

Contents of [1](https://archlinux.org/packages/community/x86_64/dunst),
[2](https://archlinux.org/packages/extra/x86_64/nitrogen),
[3](https://archlinux.org/packages/community/x86_64/openbox),
[4](https://archlinux.org/packages/community/x86_64/rofi),
[5](https://aur.archlinux.org/packages/rxvt-unicode-truecolor-wide-glyphs),
[6](https://archlinux.org/packages/community/x86_64/tint2),
[7](https://archlinux.org/packages/community/x86_64/picom),
[8](https://aur.archlinux.org/packages/obmenu-generator),
[9](https://archlinux.org/packages/community/any/perl-gtk3).

---

**Audio-server and audio stuff.**

I personally use pulseaudio, mpd and ncmpcpp are recommended as they are integrated by default.

```sh
pulseaudio pulseaudio-alsa mpd mpc ncmpcpp
```

Contents of [1](https://archlinux.org/packages/extra/x86_64/pulseaudio),
[2](https://archlinux.org/packages/extra/x86_64/pulseaudio-alsa),
[3](https://archlinux.org/packages/extra/x86_64/mpd),
[4](https://archlinux.org/packages/extra/x86_64/mpc),
[5](https://archlinux.org/packages/community/x86_64/ncmpcpp).

MPRIS-enabled media players are also integrated, such as [spotify](https://wiki.archlinux.org/title/spotify).

---

**Extended utilities. Required, but just as necessary.**

All of the below if not installed, certain functionality will display a message when needed, some will not.

```sh
alsa-utils brightnessctl imagemagick scrot w3m wireless_tools xclip xsettingsd xss-lock
```

Contents of [1](https://archlinux.org/packages/extra/x86_64/alsa-utils),
[2](https://archlinux.org/packages/community/x86_64/brightnessctl),
[3](https://archlinux.org/packages/extra/x86_64/imagemagick),
[4](https://archlinux.org/packages/community/x86_64/scrot),
[5](https://archlinux.org/packages/extra/x86_64/w3m),
[6](https://archlinux.org/packages/core/x86_64/wireless_tools),
[7](https://archlinux.org/packages/extra/x86_64/xclip),
[8](https://archlinux.org/packages/community/x86_64/xsettingsd),
[9](https://archlinux.org/packages/community/x86_64/xss-lock).

Choose your own polkit authentication-agent.
[polkit-gnome](https://archlinux.org/packages/community/x86_64/polkit-gnome)?

---

**Additionals for completion of desktop compositions.**

Just like mpd and ncmpcpp, configurations are included as [EXTRA_JOYFUL](./EXTRA_JOYFUL), some are integrated.

```sh
thunar thunar-archive-plugin thunar-volman ffmpegthumbnailer tumbler
```

Contents of [1](https://archlinux.org/packages/extra/x86_64/thunar),
[2](https://archlinux.org/packages/extra/x86_64/thunar-archive-plugin),
[3](https://archlinux.org/packages/extra/x86_64/thunar-volman),
[4](https://archlinux.org/packages/extra/x86_64/ffmpegthumbnailer),
[5](https://archlinux.org/packages/extra/x86_64/tumbler).

Gsimplecal was used to display calendar pop-ups from the tint2 panel, and pavucontrol to control pulseaudio-sinks.

```sh
geany geany-plugins gimp gsimplecal inkscape mpv parcellite pavucontrol viewnior xfce4-power-manager
```

Contents of [1](https://archlinux.org/packages/community/x86_64/geany),
[2](https://archlinux.org/packages/community/x86_64/geany-plugins),
[3](https://archlinux.org/packages/extra/x86_64/gimp),
[4](https://archlinux.org/packages/community/x86_64/gsimplecal),
[5](https://archlinux.org/packages/extra/x86_64/inkscape),
[6](https://archlinux.org/packages/community/x86_64/mpv),
[7](https://archlinux.org/packages/community/x86_64/parcellite),
[8](https://archlinux.org/packages/extra/x86_64/pavucontrol),
[9](https://archlinux.org/packages/community/x86_64/viewnior),
[10](https://archlinux.org/packages/extra/x86_64/xfce4-power-manager).

I personally don't use neofetch anymore and use system-information via rofi, it's already scripted.

```sh
htop nano #neofetch
```

Contents of [1](https://archlinux.org/packages/extra/x86_64/htop),
[2](https://archlinux.org/packages/core/x86_64/nano),
[3](https://archlinux.org/packages/community/any/neofetch).

[Here for improved nanorc with syntax-highlighting](https://github.com/scopatz/nanorc).

I personally use NetworkManager (and IWD as wireless back-end) with nm-applet,
[here it is](https://wiki.archlinux.org/title/NetworkManager#Front-ends).

</details>

<details>
<summary><b>1. Gentoo source-based Linux distributions</b></summary>

[Gentoo Linux](https://gentoo.org) extremely recommended. Expert!

**Didn't know how to install packages?**

```sh
💲 doas emerge -av atom1 atom2 ... atomN
```

> Note that some packages require accepting [arch~ keywords](https://wiki.gentoo.org/wiki/ACCEPT_KEYWORDS).
> It's highly recommended.

> See also USE flags, it's complicated to explain.
> [You may want to see mine](https://github.com/owl4ce/hmg/tree/main/etc/portage).

---

**X.Org server and it's utilities. This is essentials.**

```sh
x11-base/xorg-server x11-apps/xrandr
```

Contents of [1](https://packages.gentoo.org/packages/x11-base/xorg-server),
[2](https://packages.gentoo.org/packages/x11-apps/xrandr).

---

**Now, the UI kits and functionality. This is required.**

URxvt is highly recommended terminal emulator by default. Picom is optional, but recommended.

> My own [Lilium portage overlay](https://github.com/owl4ce/lilium) contains enhancements.  
> `x11-terms/rxvt-unicode::lilium`

> For pixel-perfect, subtract 1px in [`~/.Xresources`](./.Xresources#L9) and [`~/.joyfuld`](./.joyfuld#L161-L162).

```sh
x11-misc/dunst x11-misc/nitrogen x11-wm/openbox x11-misc/rofi x11-terms/rxvt-unicode::lilium x11-misc/tint2 \=x11-misc/picom-9999 x11-misc/obmenu-generator dev-perl/Gtk3
```

Contents of [1](https://packages.gentoo.org/packages/x11-misc/dunst),
[2](https://packages.gentoo.org/packages/x11-misc/nitrogen),
[3](https://packages.gentoo.org/packages/x11-wm/openbox),
[4](https://packages.gentoo.org/packages/x11-misc/rofi),
[5](https://github.com/owl4ce/lilium/tree/main/x11-terms/rxvt-unicode),
[6](https://packages.gentoo.org/packages/x11-misc/tint2),
[7](https://packages.gentoo.org/packages/x11-misc/picom),
[8](https://packages.gentoo.org/packages/x11-misc/obmenu-generator),
[9](https://packages.gentoo.org/packages/dev-perl/Gtk3).

---

**Audio-server and audio stuff.**

I personally use pulseaudio, mpd and ncmpcpp are recommended as they are integrated by default.

```sh
media-sound/pulseaudio media-sound/mpd media-sound/mpc media-sound/ncmpcpp
```

Contents of [1](https://packages.gentoo.org/packages/media-sound/pulseaudio),
[2](https://packages.gentoo.org/packages/media-sound/mpd),
[3](https://packages.gentoo.org/packages/media-sound/mpc),
[4](https://packages.gentoo.org/packages/media-sound/ncmpcpp).

MPRIS-enabled media players are also integrated, such as [spotify](https://wiki.gentoo.org/wiki/Spotify).

---

**Extended utilities. Required, but just as necessary.**

All of the below if not installed, certain functionality will display a message when needed, some will not.

> I personally don't use [GURU portage overlay](https://wiki.gentoo.org/wiki/Project:GURU)
> and build manually instead.  
> `app-misc/brightnessctl::guru`

```sh
app-misc/brightnessctl::guru media-gfx/imagemagick media-gfx/scrot www-client/w3m net-wireless/wireless-tools x11-misc/xclip x11-misc/xsettingsd x11-misc/xss-lock
```

Contents of [1](https://gitweb.gentoo.org/repo/proj/guru.git/tree/app-misc/brightnessctl),
[2](https://packages.gentoo.org/packages/media-gfx/imagemagick),
[3](https://packages.gentoo.org/packages/media-gfx/scrot),
[4](https://packages.gentoo.org/packages/www-client/w3m),
[5](https://packages.gentoo.org/packages/net-wireless/wireless-tools),
[6](https://packages.gentoo.org/packages/x11-misc/xclip),
[7](https://packages.gentoo.org/packages/x11-misc/xsettingsd),
[8](https://packages.gentoo.org/packages/x11-misc/xss-lock).

Choose your own polkit authentication-agent.
[polkit-gnome](https://packages.gentoo.org/packages/gnome-extra/polkit-gnome)?

---

**Additionals for completion of desktop compositions.**

Just like mpd and ncmpcpp, configurations are included as [EXTRA_JOYFUL](./EXTRA_JOYFUL), some are integrated.

```sh
xfce-base/thunar xfce-extra/thunar-archive-plugin xfce-extra/thunar-volman media-video/ffmpegthumbnailer xfce-extra/tumbler
```

Contents of [1](https://packages.gentoo.org/packages/xfce-base/thunar),
[2](https://packages.gentoo.org/packages/xfce-extra/thunar-archive-plugin),
[3](https://packages.gentoo.org/packages/xfce-extra/thunar-volman),
[4](https://packages.gentoo.org/packages/media-video/ffmpegthumbnailer),
[5](https://packages.gentoo.org/packages/xfce-extra/tumbler).

Gsimplecal was used to display calendar pop-ups from the tint2 panel, and pavucontrol to control pulseaudio-sinks.

> I personally don't use [Miramir's portage overlay](https://github.com/miramir/miramir-layman)
> and build manually instead.  
> `x11-misc/gsimplecal::miramir`

```sh
dev-util/geany dev-util/geany-plugins media-gfx/gimp x11-misc/gsimplecal::miramir media-gfx/inkscape media-video/mpv x11-misc/parcellite media-sound/pavucontrol media-gfx/viewnior xfce-extra/xfce4-power-manager
```

Contents of [1](https://packages.gentoo.org/packages/dev-util/geany),
[2](https://packages.gentoo.org/packages/dev-util/geany-plugins),
[3](https://packages.gentoo.org/packages/media-gfx/gimp),
[4](https://github.com/miramir/miramir-layman/tree/master/x11-misc/gsimplecal),
[5](https://packages.gentoo.org/packages/media-gfx/inkscape),
[6](https://packages.gentoo.org/packages/media-video/mpv),
[7](https://packages.gentoo.org/packages/x11-misc/parcellite),
[8](https://packages.gentoo.org/packages/media-sound/pavucontrol),
[9](https://packages.gentoo.org/packages/media-gfx/viewnior),
[10](https://packages.gentoo.org/packages/xfce-extra/xfce4-power-manager).

I personally don't use neofetch anymore and use system-information via rofi, it's already scripted.

```sh
sys-process/htop #app-misc/neofetch
```

Contents of [1](https://packages.gentoo.org/packages/sys-process/htop),
[2](https://packages.gentoo.org/packages/app-misc/neofetch).

[Here for improved nanorc with syntax-highlighting](https://github.com/scopatz/nanorc).

I personally use NetworkManager (and IWD as wireless back-end) with nm-applet,
[here it is](https://wiki.gentoo.org/wiki/NetworkManager#GTK_GUIs).

</details>

<details>
<summary><b>1. Another independent Linux distributions</b></summary>

Need [contributors](#deciduous_tree--contributing) to encapsulate dependencies.

<pre align="center">
The Linux philosophy is ‘Laugh in the face of danger’.
Oops. Wrong One. ‘Do it yourself’.

- Linus Torvalds
</pre>

</details>

<details>
<summary><b>1. Berkeley Software Distribution (BSD) variants</b></summary>

The [BSD variants](https://en.wikipedia.org/wiki/Comparison_of_BSD_operating_systems)
haven't been tested at all, probably some of the extensions are [GNU](https://gnu.org)'s
and [Linux-specific](https://refspecs.linuxfoundation.org/lsb.shtml).

</details>

<details>
<summary><b>2. Additionally Z shell with oh-my-zsh plugins</b></summary>

Ensure you have installed zsh with system package manager as per distribution.

```sh
💲 sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"
```

```sh
💲 sudo chsh -s $(command -v zsh)
```

```sh
💲 git clone --depth 1 https://github.com/zdharma-continuum/fast-syntax-highlighting.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/fast-syntax-highlighting
```

```sh
💲 git clone --depth 1 https://github.com/zsh-users/zsh-autosuggestions.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions
```

```sh
💲 git clone --depth 1 https://github.com/zsh-users/zsh-completions.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-completions
```

</details>

### :hibiscus: ‎ <samp>INSTALLATION (PREREQUISITES)</samp>

<details>
<summary><b>1. Fonts</b></summary>

| Typefaces                                                                                                                 | License                                                                         | The path of extracted files from the archive        |
|:--------------------------------------------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------|:----------------------------------------------------|
| [GNOME Cantarell](https://download-fallback.gnome.org/sources/cantarell-fonts/0.303/cantarell-fonts-0.303.1.tar.xz)       | [OFL-1.1](https://gitlab.gnome.org/GNOME/cantarell-fonts/-/blob/master/COPYING) | `cantarell-fonts-0.303.1/prebuilt/Cantarell-VF.otf` |
| [Google Comfortaa Regular](https://raw.githubusercontent.com/googlefonts/comfortaa/main/fonts/OTF/Comfortaa-Regular.otf)  | [OFL-1.1](https://github.com/googlefonts/comfortaa/blob/main/OFL.txt)                                                                 |
| [Google Comfortaa Bold](https://raw.githubusercontent.com/googlefonts/comfortaa/main/fonts/OTF/Comfortaa-Bold.otf)        | [OFL-1.1](https://github.com/googlefonts/comfortaa/blob/main/OFL.txt)                                                                 |
| [Feather IcoMoon](https://github.com/owl4ce/dotfiles/releases/download/ng/Feather.ttf)                                    | [MIT](https://github.com/feathericons/feather/blob/master/LICENSE) ([FAQ](https://icomoon.io/#faq/license))                           |
| [Material IcoMoon](https://github.com/owl4ce/dotfiles/releases/download/ng/Material.ttf)                                  | [Apache-2.0](https://github.com/Templarian/MaterialDesign/blob/master/LICENSE)                                                        |
| [Iosevka Nerd Font ... Mono](https://github.com/owl4ce/dotfiles/releases/download/ng/Iosevka.Nerd.Font.Complete.Mono.ttf) | [LICENSE](https://github.com/ryanoasis/nerd-fonts/blob/master/LICENSE)                                                                |
| [M+ 1mn Nerd Font Complete](https://github.com/owl4ce/dotfiles/releases/download/ng/M+.1mn.Nerd.Font.Complete.ttf)        | [LICENSE](https://github.com/ryanoasis/nerd-fonts/blob/master/LICENSE)                                                                |
| [M+ 1mn Nerd Font ... Mono](https://github.com/owl4ce/dotfiles/releases/download/ng/M+.1mn.Nerd.Font.Complete.Mono.ttf)   | [LICENSE](https://github.com/ryanoasis/nerd-fonts/blob/master/LICENSE)                                                                |
| [GNU Unifont](https://unifoundry.com/pub/unifont/unifont-14.0.02/font-builds/unifont-14.0.02.ttf)                         | [LICENSE](https://unifoundry.com/LICENSE.txt)                                                                                         |

**Wget** all the above fonts (and extract if archived). Then, put them as instructed into the `~/.fonts` directory.

```bash
💲 mkdir -pv ~/.fonts/{Cantarell,Comfortaa,IcoMoon-Custom,Nerd-Patched,Unifont}
```

---

```bash
💲 wget --no-hsts -cNP ~/.fonts/Comfortaa/ https://raw.githubusercontent.com/googlefonts/comfortaa/main/fonts/OTF/Comfortaa-{Bold,Regular}.otf
```

```bash
💲 wget --no-hsts -cNP ~/.fonts/IcoMoon-Custom/ https://github.com/owl4ce/dotfiles/releases/download/ng/{Feather,Material}.ttf
```

```sh
💲 wget --no-hsts -cNP ~/.fonts/Nerd-Patched/ https://github.com/owl4ce/dotfiles/releases/download/ng/M+.1mn.Nerd.Font.Complete.ttf
```

```bash
💲 wget --no-hsts -cNP ~/.fonts/Nerd-Patched/ https://github.com/owl4ce/dotfiles/releases/download/ng/{M+.1mn,Iosevka}.Nerd.Font.Complete.Mono.ttf
```

```sh
💲 wget --no-hsts -cNP ~/.fonts/Unifont/ https://unifoundry.com/pub/unifont/unifont-14.0.02/font-builds/unifont-14.0.02.ttf
```

```sh
💲 wget --no-hsts -cN https://download-fallback.gnome.org/sources/cantarell-fonts/0.303/cantarell-fonts-0.303.1.tar.xz
```

---

```sh
💲 tar -xvf cantarell*.tar.xz --strip-components 2 --wildcards -C ~/.fonts/Cantarell/ \*/\*/Cantarell-VF.otf
```

Additionally, install the noto ([emoji takes precedence](https://github.com/owl4ce/dotfiles/issues/176)) fonts for
broad support. [Debian](https://packages.debian.org/search?suite=sid&arch=amd64&searchon=names&keywords=fonts%20noto).
[Arch](https://archlinux.org/packages/?q=fonts+noto). [Gentoo](https://packages.gentoo.org/packages/search?q=fonts+noto).

</details>

<details>
<summary><b>2. Icons</b></summary>

| Icons                                                                                                     | License                                                                                     | Usability                   |
|:----------------------------------------------------------------------------------------------------------|:--------------------------------------------------------------------------------------------|:----------------------------|
| [Gladient](https://github.com/owl4ce/dotfiles/releases/download/ng/Gladient_JfD.tar.xz)                   | PROPIETARY ([?](https://play.google.com/store/apps/details?id=com.maxghani.gladient))       | Openbox desktop (root-)menu |
| [Papirus-Custom](https://github.com/owl4ce/dotfiles/releases/download/ng/Papirus-Custom.tar.xz)           | [GPL-3.0](https://github.com/PapirusDevelopmentTeam/papirus-icon-theme/blob/master/LICENSE) | Universal                   |
| [Papirus-Dark-Custom](https://github.com/owl4ce/dotfiles/releases/download/ng/Papirus-Dark-Custom.tar.xz) | [GPL-3.0](https://github.com/PapirusDevelopmentTeam/papirus-icon-theme/blob/master/LICENSE) | Universal                   |

**Wget** all the above icons (and extract if archived). Then, put them into the `~/.icons` directory.

```sh
💲 mkdir -pv ~/.icons
```

---

```bash
💲 wget --no-hsts -cN https://github.com/owl4ce/dotfiles/releases/download/ng/{Gladient_JfD,Papirus{,-Dark}-Custom}.tar.xz
```

---

```sh
💲 tar -xf Gladient_JfD.tar.xz -C ~/.icons/
```

```sh
💲 tar -xf Papirus-Custom.tar.xz -C ~/.icons/
```

```sh
💲 tar -xf Papirus-Dark-Custom.tar.xz -C ~/.icons/
```

---

```sh
💲 sudo ln -vs ~/.icons/Papirus-Custom /usr/share/icons/
```

```sh
💲 sudo ln -vs ~/.icons/Papirus-Dark-Custom /usr/share/icons/
```

**Why do I need to link icons to [/usr](https://tldp.org/LDP/Linux-Filesystem-Hierarchy/html/usr.html)?**  
It's [required by dunst program](https://github.com/owl4ce/dotfiles/commit/bdcadc5c1d869a073c5038bce4ef26d0340275a3)
to display the notification icon sent by the program.

</details>

<details>
<summary><b>3. Wallpapers</b></summary>

| Wallpapers                                                                                                 | License                                                              | The path where it will be put |
|:-----------------------------------------------------------------------------------------------------------|:---------------------------------------------------------------------|:------------------------------|
| [batik-1_4K](https://github.com/owl4ce/dotfiles/releases/download/ng/batik-1_4K.jpg)                       | [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0) | `~/.wallpapers/mechanical`    |
| [okita-souji_FHD](https://github.com/owl4ce/dotfiles/releases/download/ng/okita-souji_FHD.jpg)             | [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0) | `~/.wallpapers/mechanical`    |
| [cherry-blossoms_FHD](https://github.com/owl4ce/dotfiles/releases/download/ng/cherry-blossoms_FHD.jpg)     | [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0) | `~/.wallpapers/eyecandy`      |
| [floral-artistic-2_FHD](https://github.com/owl4ce/dotfiles/releases/download/ng/floral-artistic-2_FHD.jpg) | [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0) | `~/.wallpapers/eyecandy`      |

> **DISCLAIMER!!!**  
> I don't own the artworks (because I couldn't find the link to the originals),
> so if you the owner of the artworks with proof and want me to remove it
> [please let me know](./CODE_OF_CONDUCT.md#enforcement).
> - [桜セイバー沖田総司](https://pixiv.net/en/artworks/59740059)
> - [桜](https://pixiv.net/en/artworks/80518034)
> - [沖田総司](https://pixiv.net/en/artworks/62996457)

**Wget** all the above wallpapers and put them as instructed into the `~/.wallpapers` directory.

```bash
💲 mkdir -pv ~/.wallpapers/{mechanical,eyecandy}
```

---

```bash
💲 wget --no-hsts -cNP ~/.wallpapers/mechanical/ https://github.com/owl4ce/dotfiles/releases/download/ng/{batik-1_4K,okita-souji_FHD}.jpg
```

```bash
💲 wget --no-hsts -cNP ~/.wallpapers/eyecandy/ https://github.com/owl4ce/dotfiles/releases/download/ng/{cherry-blossoms,floral-artistic-2}_FHD.jpg
```

Old wallpapers [can be found here](https://github.com/owl4ce/depfiles/tree/3.2/.wallpaper).

</details>

<details>
<summary><b>4. Extensions (URxvt)</b></summary>

| Extensions                                                                                   | License                                                                           | Usability         |
|:---------------------------------------------------------------------------------------------|:----------------------------------------------------------------------------------|:------------------|
| [resize-font](https://raw.githubusercontent.com/simmel/urxvt-resize-font/master/resize-font) | [ISC](https://github.com/simmel/urxvt-resize-font/blob/master/resize-font#L2-L15) | Font resizer      |
| [tabbedex](https://raw.githubusercontent.com/mina86/urxvt-tabbedex/master/tabbedex)          | [GPL-3.0](https://github.com/mina86/urxvt-tabbedex/blob/master/LICENSE)           | Tab functionality |

**cURL** all the above perl-scripts and put them into the `~/.urxvt/ext` directory.

```sh
💲 mkdir -pv ~/.urxvt/ext
```

---

```sh
💲 (cd ~/.urxvt/ext/; curl -LO https://raw.githubusercontent.com/simmel/urxvt-resize-font/master/resize-font)
```

```sh
💲 (cd ~/.urxvt/ext/; curl -LO https://raw.githubusercontent.com/mina86/urxvt-tabbedex/master/tabbedex)
```

</details>

### :cherry_blossom: ‎ <samp>INSTALLATION (DOTFILES)</samp>

<details>
<summary><b>1. Synchronize minimal .files</b></summary>

You can clone or [download as archive](https://github.com/owl4ce/dotfiles/releases/tag/ng).
Then, put all the .files in the dotfiles directory into the user's home directory. Assume you
clone it in the `~/Documents` directory. I recommend to synchronize with rsync program.

```sh
💲 cd ~/Documents/
```

> This repository auto-mirrored to https://gitlab.com/owl4ce/dotfiles.git.

```sh
💲 git clone --depth 1 --recurse-submodules https://github.com/owl4ce/dotfiles.git
```

```sh
💲 rsync -avxHAXP --exclude-from=- dotfiles/. ~/ << "EXCLUDE"
.git*
LICENSE
*.md
EXTRA_JOYFUL
EXCLUDE
```

> Ensure the rsync command must be correct as above. The following is for completion of desktop compositions.

```sh
💲 rsync -avxHAXP --exclude-from=- dotfiles/EXTRA_JOYFUL/. ~/ << "EXCLUDE"
.git*
neofetch
EXCLUDE
```

> - **cp** is for duplicating stuff and by default only ensures files have unique full pathnames.
> - **rsync** is for synchronizing stuff and uses size and timestamp of files to decide if they should be replaced.

> | Options                   | Description                                         |
> |:--------------------------|:----------------------------------------------------|
> | `-a`, `--archive`         | archive mode; equals `-rlptgoD` (no `-H`,`-A`,`-X`) |
> | `-v`, `--verbose`         | increase verbosity                                  |
> | `-x`, `--one-file-system` | don't cross filesystem boundaries                   |
> | `-H`, `--hard-links`      | preserve hard links                                 |
> | `-A`, `--acls`            | preserve ACLs (implies `--perms`)                   |
> | `-X`, `--xattrs`          | preserve extended attributes                        |
> | `-P`                      | show progress during transfer                       |
> | `--exclude-from=-`        | read exclude patterns from FILE (stdin)             |

I recommend not deleting the dotfiles directory after cloning to make [upgrading easier](#sunflower--sync-for-updates).

</details>

<details>
<summary><b>2. Regenerate the font caches</b></summary>

This ensures all existing caches are cleaned and regenerated for all installed fonts.

```sh
💲 fc-cache -rv
```

</details>

<details>
<summary><b>3. The step you're waiting for</b></summary>

The final step is to login to the openbox-session, basically login from your display manager
such as lightdm, gdm, etc. If you're using [`~/.xinitrc`](https://wiki.archlinux.org/title/Xinit)
without a display manager, simply add the following one-liner command at the end.

**Systemd-based Linux distributions**

```sh
exec openbox-session
```

**[Init-freedom](https://devuan.org/os/init-freedom) Linux distributions**

```sh
exec dbus-launch --exit-with-x11 openbox-session
```

Then you can proceed to [guides](#herb--guides). Explore!

</details>

### :sunflower: ‎ <samp>SYNC FOR UPDATES</samp>

<details>
<summary><b>Click or tap to extend</b></summary>

Since I recommend using rsync from the beginning, the easiest way is to list the files (via shell
[heredocs](https://tldp.org/LDP/abs/html/here-docs.html)) that won't be updated to avoid replacing
personal files with .files. First, update the local repository with the remote git repository.

> Remember where you cloned the repository. We assumed that it was in the `~/Documents` directory.

```sh
💲 cd ~/Documents/
```

```sh
💲 (cd dotfiles/; git pull --depth 1 --recurse-submodules --rebase)
```

```sh
💲 rsync -avxHAXP --exclude-from=- dotfiles/. ~/ << "EXCLUDE"
.git*
LICENSE
*.md
*.joy
settings.ini
mpd.state
autostart.sh
environment
tray
eyecandy.rasi
mechanical.rasi
shared.rasi
EXTRA_JOYFUL
.gtkrc-2.0
.joyfuld
.Xresources
EXCLUDE
```

> Use the find program to check the pattern. It's called [globbing](https://en.wikipedia.org/wiki/Glob_(programming)).
> ```sh
> 💲 find dotfiles/ -iname 'PATTERN'
> ```

</details>

## :herb: ‎ <samp>GUIDES</samp>

<details>
<summary><b>Joyful Desktop environment variables</b></summary>

[`~/.joyfuld`](./.joyfuld)

Manage all your settings there. I hope all the comments there are easy to understand. ^^

</details>

<details>
<summary><b>Touchpad tap-to-click (<a href="https://wiki.archlinux.org/title/Libinput#Tapping_button_re-mapping">libinput</a>)</b></summary>

`/etc/X11/xorg.conf.d/30-touchpad.conf`

```cfg
Section "InputClass"
    Identifier "touchpad"
    Driver "libinput"
    MatchIsTouchpad "on"
    Option "Tapping" "on"
    Option "TappingButtonMap" "lmr"
EndSection
```

</details>

<details>
<summary><b>Openbox autostart</b></summary>

[`~/.config/openbox/autostart.sh`](./.config/openbox/autostart.sh)

The unix-shell syntax, POSIX-compliant is highly recommended. Don't change the default, possibly broken.

</details>

<details>
<summary><b>User's tray programs</b></summary>

[`~/.config/openbox/tray`](./.config/openbox/tray)

Single program (and if any, with arguments) for each line. It will be restarted after switching modes.

</details>

<details>
<summary><b>User's environment variables</b></summary>

[`~/.config/openbox/environment`](./.config/openbox/environment)

Use `export` to set user's environment variables universally. Don't add any other syntax.

</details>

<details>
<summary><b>User's preferred applications</b></summary>

[`~/.scripts/db.apps.joy`](./.scripts/db.apps.joy)

| Parameters       | Available                                                                 | Description        |
|:-----------------|:--------------------------------------------------------------------------|:-------------------|
| *terminal*       | `urxvt` [`urxvtc`](./.config/openbox/autostart.sh#L17)                    | Terminal Emulator  |
| *music_player*   | `mpd` [`MPRIS`](https://wiki.archlinux.org/title/MPRIS#Supported_clients) | Music/Media Player |
| *file_manager*   | *anything*                                                                | File Manager       |
| *session_locker* | *anything*                                                                | Session Locker     |

Terminal emulator and file manager are used universally,
both for keybindings and context menus. The terminal emulator is actually freedom-of-choice,
but it's [not integrated](./.config/openbox/joyful-desktop/terminal-set.sh#L25-L132), it displays a
notification message. The music player [can be switched](./.scripts/music-controller.sh#L73-L84) without
modifying the configuration manually, via music control button on tint2 panel, just hover it. The session
locker was [used by xss-lock program](./.config/openbox/joyful-desktop/xss-lock-tsl.sh#L26-L36) (which
[enabled in autostart](./.config/openbox/autostart.sh#L32)), triggered by systemd events and
[DPMS](https://wiki.archlinux.org/title/Display_Power_Management_Signaling).

</details>

<details>
<summary><b>Ncmpcpp and the album-art image cover</b></summary>

Update the mpd database first, via mpc or by pressing <kbd>U</kbd> in ncmpcpp.

```sh
💲 mpc -p 7777 update
```

Put an image file that [matches BRE](./.config/ncmpcpp/scripts/album-art.sh#L79)
`(album|cover|folder|artwork|front).*[.](jpe?g|png|gif|bmp)` into the directory containing
album tracks. The directory is in the `~/Music` [by default](./.config/mpd/mpd.conf#L10).
The recommended image size is 500px at ratio of 1:1 or more. So, assume you have `~/Music/YOUR_ALBUM`
directory with lots of tracks, you should put the image file to use as album-art
(related to tracks) there. [This is for URxvt only](./.joyfuld#L144-L162).

Also, I use [ALSA driver in the MPD](./.config/mpd/mpd.conf#L27-L38) to get
[bit-perfect playback](https://mpd.readthedocs.io/en/stable/user.html#bit-perfect-playback).
It's [disabled by default](./.config/mpd/mpd.state#L2-L3), you need to switch it.

</details>

<details>
<summary><b>File manager side-pane and XDG user directories</b></summary>

If you just installed thunar without XFCE, you may get side-pane without
[XDG directories](https://wiki.archlinux.org/title/XDG_user_directories) such as Documents,
Downloads, etc. After you created those directories, open thunar and select or block those directories.
Then right click and click **Send To** 🡲 **Side Pane**. [It's basically plain configuration file](https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux/8/html/using_the_desktop_environment_in_rhel_8/managing-bookmarks-in-gnome_using-the-desktop-environment-in-rhel-8#bookmarks-in-gnome_managing-bookmarks-in-gnome).
The following command generates those directories.

```sh
💲 xdg-user-dirs-update
```

If you want to get 100% thunar looks similar to my screenshot, ensure to copy my
[thunar configuration](./EXTRA_JOYFUL/.config/xfce4/xfconf/xfce-perchannel-xml/thunar.xml)
(before opening for the first time). Then hide Computer, Desktop, Recent,
or whatever you want by right clicking **Places** on thunar side-pane. By default,
my thunar side-pane configuration uses simple 16px icons. [Suggested by Papirus Development
Team](https://github.com/PapirusDevelopmentTeam/papirus-icon-theme#manual-fixes).

</details>

### :tanabata_tree: ‎ <samp>ADDITIONALS</samp>

- [Capitaine Cursors Theme](https://pling.com/p/1148692)
- [Do Live Calculations in Rofi!](https://github.com/svenstaro/rofi-calc)
- [Telegram Desktop Nord Theme](https://t.me/addtheme/nord_colors)
- [Recommended Modern Unix Utilities](https://github.com/ibraheemdev/modern-unix)
- [Chrome-based Hardware Acceleration](https://linuxuprising.com/2021/01/how-to-enable-hardware-accelerated.html)
- [Automatic Tiling for EWMH-compliant WMs](https://github.com/blrsn/zentile)

## :four_leaf_clover: ‎ <samp>KEY BINDINGS</samp>

<details>
<summary><b>Openbox (<a href="./.config/openbox/rc.xml#L175-L827">rc.xml</a>)</b></summary>

| Key                                                                                                                                                         | Action                                            |
|:------------------------------------------------------------------------------------------------------------------------------------------------------------|:--------------------------------------------------|
|                                                                                                                                                             |                                                   |
| **Window Management and more**                                                                                                                              |                                                   |
| <kbd>super</kbd> + <kbd>⯇</kbd>                                                                                                                            | Move window focus to left-side                    |
| <kbd>super</kbd> + <kbd>⯈</kbd>                                                                                                                            | Move window focus to right-side                   |
| <kbd>super</kbd> + <kbd>⯅</kbd>                                                                                                                            | Move window focus to up-side                      |
| <kbd>super</kbd> + <kbd>⯆</kbd>                                                                                                                            | Move window focus to down-side                    |
| <kbd>super</kbd> + <kbd>shift</kbd> + <kbd>⯇</kbd>                                                                                                         | Move focused window to left-side                  |
| <kbd>super</kbd> + <kbd>shift</kbd> + <kbd>⯈</kbd>                                                                                                         | Move focused window to right-side                 |
| <kbd>super</kbd> + <kbd>shift</kbd> + <kbd>⯅</kbd>                                                                                                         | Move focused window to up-side                    |
| <kbd>super</kbd> + <kbd>shift</kbd> + <kbd>⯆</kbd>                                                                                                         | Move focused window to down-side                  |
| <kbd>super</kbd> + <kbd>1</kbd> / <kbd>2</kbd> / <kbd>3</kbd> / <kbd>4</kbd> / <kbd>5</kbd> / <kbd>6</kbd> / <kbd>7</kbd> / <kbd>8</kbd>                    | Move to N desktop/workspace                       |
| <kbd>super</kbd> + <kbd>shift</kbd> + <kbd>1</kbd> / <kbd>2</kbd> / <kbd>3</kbd> / <kbd>4</kbd> / <kbd>5</kbd> / <kbd>6</kbd> / <kbd>7</kbd> / <kbd>8</kbd> | Move focused window to N desktop/workspace        |
| <kbd>alt</kbd> + <kbd>ㅤㅤㅤㅤ</kbd>                                                                                                                         | Show (client-)menu of focused window              |
| <kbd>super</kbd> + <kbd>C</kbd>                                                                                                                             | Close/kill focused window                         |
| <kbd>super</kbd> + <kbd>D</kbd>                                                                                                                             | Toggle show desktop                               |
| <kbd>super</kbd> + <kbd>F</kbd>                                                                                                                             | Toggle fullscreen for focused window              |
| <kbd>super</kbd> + <kbd>ㅤㅤㅤㅤ</kbd>                                                                                                                       | Show desktop (root-)menu                          |
| <kbd>super</kbd> + <kbd>T</kbd>                                                                                                                             | Toggle decorations of focused window              |
| <kbd>super</kbd> + <kbd>X</kbd>                                                                                                                             | Toggle maximize for focused window                |
| <kbd>super</kbd> + <kbd>Z</kbd>                                                                                                                             | Toggle iconify (or minimize) for focused window   |
| <kbd>alt</kbd> + <kbd>tab</kbd>                                                                                                                             | Switch active window to next window               |
| <kbd>alt</kbd> + <kbd>shift</kbd> + <kbd>tab</kbd>                                                                                                          | Switch active window to previous window           |
| <kbd>super</kbd> + <kbd>esc</kbd>                                                                                                                           | Open rofi extensions menu                         |
| <kbd>super</kbd> + <kbd>prt sc</kbd>                                                                                                                        | Open rofi screenshots menu                        |
| <kbd>super</kbd> + <kbd>R</kbd>                                                                                                                             | Open rofi main menu                               |
| <kbd>prt sc</kbd>                                                                                                                                           | Screenshot                                        |
| <kbd>ctrl</kbd> + <kbd>prt sc</kbd>                                                                                                                         | Countdown screenshot                              |
| <kbd>shift</kbd> + <kbd>prt sc</kbd>                                                                                                                        | Selection screenshot                              |
| <kbd>ctrl</kbd> + <kbd>esc</kbd>                                                                                                                            | Pop-up notification history                       |
| <kbd>ctrl</kbd> + <kbd>enter</kbd>                                                                                                                          | Open current notification context-menu            |
| <kbd>ctrl</kbd> + <kbd>ㅤㅤㅤㅤ</kbd>                                                                                                                        | Close current notification                        |
| <kbd>ctrl</kbd> + <kbd>shift</kbd> + <kbd>ㅤㅤㅤㅤ</kbd>                                                                                                     | Close all notifications                           |
| <kbd>super</kbd> + <kbd>E</kbd>                                                                                                                             | Open user's preferred file manager                |
| <kbd>super</kbd> + <kbd>L</kbd>                                                                                                                             | Lock current session with user's preferred locker |
| <kbd>super</kbd> + <kbd>enter</kbd>                                                                                                                         | Open user's preferred terminal emulator           |
| <kbd>super</kbd> + <kbd>shift</kbd> + <kbd>enter</kbd>                                                                                                      | Reverse terminal emulator background-foreground   |
| <kbd>super</kbd> + <kbd>shift</kbd> + <kbd>R</kbd>                                                                                                          | Restart UI                                        |
|                                                                                                                                                             |                                                   |
| **Brightness Control**                                                                                                                                      |                                                   |
| <kbd>🔆+</kbd>                                                                                                                                              | Increase brightness by N%                         |
| <kbd>🔆-</kbd>                                                                                                                                              | Decrease brightness by N%                         |
|                                                                                                                                                             |                                                   |
| **Audio-volume Control**                                                                                                                                    |                                                   |
| <kbd>🔊+</kbd>                                                                                                                                              | Increase audio-volume by N%                       |
| <kbd>🔊-</kbd>                                                                                                                                              | Decrease audio-volume by N%                       |
| <kbd>🔇</kbd>                                                                                                                                               | Toggle mute                                       |
|                                                                                                                                                             |                                                   |
| **Media Control**                                                                                                                                           |                                                   |
| <kbd>⏮</kbd>                                                                                                                                               | Previous track                                    |
| <kbd>⏭</kbd>                                                                                                                                               | Next track                                        |
| <kbd>⏹</kbd>                                                                                                                                               | Stop playing music                                |
| <kbd>⏯</kbd>                                                                                                                                               | Toggle play/pause                                 |
|                                                                                                                                                             |                                                   |
| **Combo Keyboard and Pointing Device**                                                                                                                      |                                                   |
| <kbd>super</kbd> + <kbd>`left click`</kbd> (hold)                                                                                                           | Move focused window freely                        |
| <kbd>super</kbd> + <kbd>`right click`</kbd> (hold)                                                                                                          | Resize focused window freely                      |
| <kbd>super</kbd> + <kbd>`scroll up`</kbd> / <kbd>`scroll down`</kbd>                                                                                        | Move desktop/workspace to previous or next        |
|                                                                                                                                                             |                                                   |
| **Cursor on Desktop**                                                                                                                                       |                                                   |
| <kbd>`middle click`</kbd>                                                                                                                                   | Show desktop/workspace lists                      |
| <kbd>`right click`</kbd>                                                                                                                                    | Show desktop (root-)menu                          |
| <kbd>`scroll up`</kbd> / <kbd>`scroll down`</kbd>                                                                                                           | Move desktop/workspace to previous or next        |
|                                                                                                                                                             |                                                   |
| **Cursor on Window Titlebar**                                                                                                                               |                                                   |
| <kbd>`left click`</kbd> (or simply hover)                                                                                                                   | Focus and raise window                            |
| <kbd>`middle click`</kbd>                                                                                                                                   | Switch active window to previous or next window   |
| <kbd>`right click`</kbd>                                                                                                                                    | Show (client-)menu of focused window              |
| <kbd>`scroll up`</kbd> / <kbd>`scroll down`</kbd>                                                                                                           | Roll up or down focused window                    |

> **LEGEND**  
> [<kbd>super</kbd>](https://en.wikipedia.org/wiki/Super_key_(keyboard_button))

</details>

<details>
<summary><b>Parcellite (<a href="./EXTRA_JOYFUL/.config/parcellite/parcelliterc#L38-L41">parcelliterc</a>)</b></summary>

| Key                                             | Action                       |
|:------------------------------------------------|:-----------------------------|
| <kbd>ctrl</kbd> + <kbd>alt</kbd> + <kbd>P</kbd> | Show menu                    |
| <kbd>ctrl</kbd> + <kbd>alt</kbd> + <kbd>H</kbd> | Show history menu            |
| <kbd>ctrl</kbd> + <kbd>alt</kbd> + <kbd>X</kbd> | Show persistent history menu |
| <kbd>ctrl</kbd> + <kbd>alt</kbd> + <kbd>A</kbd> | Show action menu             |

</details>

<details>
<summary><b>URxvt (<a href="./.Xresources">.Xresources</a>)</b></summary>

| Key                                                          | Action                             |
|:-------------------------------------------------------------|:-----------------------------------|
|                                                              |                                    |
| **Built-in**                                                 |                                    |
| <kbd>ctrl</kbd> + <kbd>shift</kbd> + <kbd>L</kbd>            | Clear scrollback buffer cleanly    |
| <kbd>ctrl</kbd> + <kbd>shift</kbd> + <kbd>C</kbd>            | Copy selection to clipboard        |
| <kbd>ctrl</kbd> + <kbd>shift</kbd> + <kbd>V</kbd>            | Paste clipboard                    |
| <kbd>ctrl</kbd> + <kbd>⯅</kbd>                              | Scroll up by line                  |
| <kbd>ctrl</kbd> + <kbd>⯆</kbd>                              | Scroll down by line                |
| <kbd>ctrl</kbd> + <kbd>home</kbd>                            | Scroll up to top                   |
| <kbd>ctrl</kbd> + <kbd>end</kbd>                             | Scroll down to bottom              |
| <kbd>ctrl</kbd> + <kbd>`right click`</kbd> (hold)            | Show context-menu                  |
|                                                              |                                    |
| **URL Selection (matcher)**                                  |                                    |
| <kbd>ctrl</kbd> + <kbd>shift</kbd> + <kbd>U</kbd>            | Activate URL selection             |
| <kbd>⯇</kbd> / <kbd>⯅</kbd> / <kbd>⯈</kbd> / <kbd>⯆</kbd> | Navigate URL selection             |
| <kbd>enter</kbd> / <kbd>`left click`</kbd>                   | Open selected URL                  |
| <kbd>esc</kbd>                                               | Deactivate URL selection           |
|                                                              |                                    |
| **Font Resizer**                                             |                                    |
| <kbd>ctrl</kbd> + <kbd>+</kbd>                               | Increase font size by Npx          |
| <kbd>ctrl</kbd> + <kbd>-</kbd>                               | Decrease font size by Npx          |
| <kbd>ctrl</kbd> + <kbd>=</kbd>                               | Reset font size to default         |
| <kbd>ctrl</kbd> + <kbd>?</kbd>                               | Show font information              |
|                                                              |                                    |
| **Tabbed Extended**                                          |                                    |
| <kbd>ctrl</kbd> + <kbd>shift</kbd> + <kbd>T</kbd>            | New tab                            |
| <kbd>ctrl</kbd> + <kbd>shift</kbd> + <kbd>R</kbd>            | Rename current tab                 |
| <kbd>ctrl</kbd> + <kbd>shift</kbd> + <kbd>W</kbd>            | Close/kill current tab             |
| <kbd>ctrl</kbd> + <kbd>pg up</kbd>                           | Jump to next tab                   |
| <kbd>ctrl</kbd> + <kbd>pg dn</kbd>                           | Jump to previous tab               |
| <kbd>ctrl</kbd> + <kbd>shift</kbd> + <kbd>pg up</kbd>        | Move current tab to next order     |
| <kbd>ctrl</kbd> + <kbd>shift</kbd> + <kbd>pg dn</kbd>        | Move current tab to previous order |

> **SHELL**  
> Most shells use the readline([3](https://www.man7.org/linux/man-pages/man3/readline.3.html#EDITING_COMMANDS)) library.
> In addition, provided by shell plugins.
> ```sh
> 💲 man 3 readline | less +/EDITING\ COMMANDS
> ```

</details>

<details>
<summary><b>Dunst (<a href="./.config/dunst/mechanical.artistic.dunstrc#L44-L46">dunstrc</a>)</b></summary>

| Key                       | Action                          |
|:--------------------------|:--------------------------------|
| <kbd>`left click`</kbd>   | Close current notification      |
| <kbd>`middle click`</kbd> | Open notifications context-menu |
| <kbd>`right click`</kbd>  | Close all notifications         |

</details>

[Anime4K shaders](https://github.com/bloc97/Anime4K/blob/master/GLSL_Instructions.md)
via [mpv](https://mpv.io/manual/master/#interactive-control) with
[custom key](./EXTRA_JOYFUL/.config/mpv/input.conf). [Ncmpcpp](https://pkgbuild.com/~jelle/ncmpcpp).
[Thunar](https://docs.xfce.org/xfce/thunar/faq#how_do_i_assign_different_keyboard_shortcuts)
with [custom action key](./EXTRA_JOYFUL/.config/Thunar/accels.scm).

## :maple_leaf: ‎ <samp>THE PHILOSOPHY</samp>

Aesthetics doesn't only look at the beauty of the results. There's beauty, in a sense, users are expected to feel
like they are part of how this was crafted. Emotion and satisfaction, relatively. Ideally, the author's idea is to
use this as a minimal "replacement" for bloated and complicated desktop environment. Pragmatically, what are the
"benefits" in our daily life, especially for low-end devices. Realistically, be "grateful" to accept the existence
of lightweight and non-proprietary software, and use it (instead of using pirated software).

Started [passively since 2018](https://github.com/owl4ce/dotfiles/wiki/My-Linux-Ricing-Journey).
Then continued self-taught research months after COVID-19 pandemic, manically. It was still only one,
manually changing styles from one to another. Until finally, combining multiple styles into multiple modes.
The author named it **Joyful** (IPA: `/ˈdʒɔɪfəl/`) **Desktop**. The name isn't random, it was inspired by a music
composed by [KODOMOi](https://kodomoi.com) along with the author's expression of wishing for love and happiness.

There are two modes with two themes totaling four, illogically representing the number in `/owl·4·ce/`, the
author's nickname. Although both are functional, the Artistic Mode is expressed as a decorative aesthetic value,
whereas Interactive Mode is aimed for those who want the practical details of statistics. Initially, the dark
theme (Fleon) was predominantly blue, and the light theme (Sweetly) was red, expressing a mixture of violet
because they tends to be blue. However, over time since the release of version 3.2, they tends to be red with
[Cherry Blossom](https://en.wikipedia.org/wiki/Cherry_blossom). Blue expresses the author's seeking peace or
serenity, violet represents light-hearted and ambition, and red is aggressive action that reflects passion.

Two themes are based on and aimed at the mood swings of users. Initially since the first release until
[version 2](https://deviantart.com/owl4ce/art/Joyful-Desktop-v2-858107208), darkness was inspired by
[Dystopia](https://en.wikipedia.org/wiki/Dystopia) (while the author listened to
[The Astonishing](https://en.wikipedia.org/wiki/The_Astonishing) by
[Dream Theater](https://en.wikipedia.org/wiki/Dream_Theater)),
a reflection of unhappiness and suffering. In contrast, natural scenery, a reflection of inner satisfaction.
Now since the pre-release [version 4](https://github.com/owl4ce/dotfiles/releases/tag/ng) has adopted the same
theme and [color scheme](./EXTRA_JOYFUL/.config/inkscape/palettes/Joyful-Desktop.gpl) from the previous release.

<pre align="center">
<a href="#maple_leaf--the-philosophy">
<img alt="" align="center" width="96%" src="https://api.star-history.com/svg?repos=owl4ce/dotfiles&type=Date"/>
</a>
</pre>

## :tulip: ‎ <samp>TIP JAR</samp>

If you enjoyed it and would like to show your appreciation, you may want to tip me here.

It's never required, but always wholeheartedly appreciated.

Thanks from the bottom of my heart! ‎ :heartpulse:

[![](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/V7V05ZACS)
[![](https://liberapay.com/assets/widgets/donate.svg)](https://liberapay.com/owl4ce/donate)

## :bouquet: ‎ <samp>ACKNOWLEDGEMENTS</samp>

|           |   | Inspiration and Resources                                   |                                                                                                                                                              |            |
|:---------:|:-:|:------------------------------------------------------------|:-------------------------------------------------------------------------------------------------------------------------------------------------------------|:----------:|
|           | 1 | [Elena](https://github.com/elenapan)                        |                                                                                                                                                              |            |
|           | 2 | [Adhi Pambudi](https://github.com/addy-dclxvi)              |                                                                                                                                                              |            |
|           | 3 | [Fikri Omar](https://github.com/fikriomar16)                |                                                                                                                                                              |            |
|           | 4 | [Rizqi Nur Assyaufi](https://github.com/bandithijo)         |                                                                                                                                                              |            |
|           | 5 | [Muktazam Hasbi Ashidiqi](https://github.com/reorr)         |                                                                                                                                                              |            |
|           | 6 | [Galih Wisnuaji](https://github.com/nekonako)               |                                                                                                                                                              |            |
|           | 7 | [Ghani Rafif](https://github.com/ekickx)                    |                                                                                                                                                              |            |
|           | 8 | [Dylan Araps](https://github.com/dylanaraps)                |                                                                                                                                                              |            |
|           | 9 | [Niivu](https://github.com/niivu)                           |                                                                                                                                                              |            |
|           |   |                                                             |                                                                                                                                                              |            |
| **Group** |   | **Contributors**                                            | **Contributions**                                                                                                                                            | **Status** |
| Unlisted  | 1 | [Ekaunt](https://github.com/ekaunt)                         | [Better rofi prompt-menu](https://github.com/owl4ce/dotfiles/pull/2).                                                                                        | Obsolete   |
| Unlisted  | 2 | [HopeBaron](https://github.com/HopeBaron)                   | [Termite configuration](https://github.com/owl4ce/dotfiles/pull/4).                                                                                          | Obsolete   |
| Unlisted  | 3 | [Justin Faber](https://github.com/vredesbyyrd)              | [Rofi matched-lines indicator](https://github.com/owl4ce/dotfiles/issues/33#issuecomment-753399179).                                                         | Merged     |
| Unlisted  | 4 | [Vcyzteen](https://github.com/vcyzteen)                     | [URxvt copy-paste with eval](https://github.com/owl4ce/dotfiles/pull/67/files#diff-76ca8b85960fd14348e9caa3ebabe00c3cf21593a94036f4ba3305c262809a34R59-R60). | Merged     |
| Verified  | * | [![](https://contrib.rocks/image?repo=owl4ce/dotfiles)](https://github.com/owl4ce/dotfiles/graphs/contributors)                                                                                                                         |
|           |   |                                                             |                                                                                                                                                              |            |
| **Based** |   | **Community**                                               | **Membership Status**                                                                                                                                        |            |
|:indonesia:| 1 | [Linuxer Desktop Art](https://facebook.com/groups/linuxart) | Self-destruct in 1443 H.                                                                                                                                     |            |
|:indonesia:| 2 | [@dotfiles_id](https://t.me/dotfiles_id)                    | I quit in the same year.                                                                                                                                     |            |
|:world_map:| 3 | [r/unixp*rn](https://reddit.com/r/unixporn)                 | Inactive for a long time.                                                                                                                                    |            |
|:world_map:| 4 | [DeviantArt](https://deviantart.com)                        | Inactive for a long time.                                                                                                                                    |            |

## :deciduous_tree: ‎ <samp>CONTRIBUTING</samp>

[Read here](./CONTRIBUTING.md).

## :jack_o_lantern: ‎ <samp>SECURITY POLICY</samp>

[Read here](./SECURITY.md).

<h1></h1>

<pre align="center">
<a href="#readme">BACK TO TOP</a>
</pre>

</div>
