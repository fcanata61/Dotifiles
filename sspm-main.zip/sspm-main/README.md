# [sspm](https://jpsspm.github.io/sspm/)

### Introduction
Simple Script Package Manager  written in bash for linux-based OS built from scratch

### Usage
>* sspm -i sspm
>* sspm info *(the manual page)* 
>* sspm -pe  *(generate an empty pkgbuild file)* 
>* sspm --destdir='../dir/dir' -ib *(build install and save package in ... )* 
>* sspm -bio ..

### Home Page

https://jpsspm.github.io/sspm/
