/******************************
** Installation Instructions **
******************************/

1) Unzip the file orore_cf.zip
2) Copy or Move the folder [Orore] in the subdirectory /home/your_user_name/conky-manager/themes/
   (short way: ~/conky-manager/themes/)
3) Start the Conky manager and enabled Orore theme 

That's all...
