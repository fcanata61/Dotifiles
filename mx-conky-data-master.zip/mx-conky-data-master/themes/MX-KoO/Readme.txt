Just install into your home..

semplice-conky-harddisks.sh (Allow this file to run as a program) it is for the Disk Mounts..
