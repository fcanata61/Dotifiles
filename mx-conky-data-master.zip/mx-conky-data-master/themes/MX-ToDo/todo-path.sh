#!/bin/bash

todofile="$HOME/Documents/todo.txt"

if [ -f $todofile ]; then
	echo '${execi 5 cat ~/Documents/todo.txt | fold -w 34 -s}'
else	
	echo '${execi 5 cat ~/.conky/MX-ToDo/use.txt | fold -w 34 -s}'
fi
