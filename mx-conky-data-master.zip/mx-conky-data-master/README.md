# mx-conky-data
Default conky configurations for mx linux
