- [ ] Does this issue occur in master?

## Description


## Error message

```
terminal output
```

## Verbose log

1. Download https://github.com/kisslinux/kiss/raw/master/kiss
2. Run `env KISS_PROMPT=0 sh -x ./kiss <arguments> > log 2>&1`
2. Upload the contents of `log`.

---

Issues without attached log file will be closed unless steps to reproduce the
problem are provided in place of it. Issues not using the template will be
closed. Feature requests and otherwise non-issues can disregard this notice.

