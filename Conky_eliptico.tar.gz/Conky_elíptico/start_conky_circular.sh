#!/bin/bash
killall conky
sleep 5 && conky -c $HOME/.Conky_elíptico/conkyrc ; 



exit 0

